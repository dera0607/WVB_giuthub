#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>

@interface SpotLogAnnotation : NSObject <MKAnnotation>
{
    NSDictionary*   _logDict;
}

// プロパティ
@property (nonatomic, retain) NSDictionary* logDict;

@end

#pragma mark -

@interface SpotLogButton : UIButton
{
    SpotLogAnnotation*  _annotation;
}

// プロパティ
@property (nonatomic, retain) SpotLogAnnotation* annotation;

@end

#pragma mark -

@interface SpotLogViewController : UIViewController <CLLocationManagerDelegate>
{
    NSMutableArray*     _logs;
    
    CLLocationManager*  _locationManager;
    
    IBOutlet UITextField*   _textField;
    IBOutlet UIButton*      _logButton;
    IBOutlet MKMapView*     _mapView;
}

// ログ管理
- (void)saveLogs;
- (void)loadLogs;

// アクション
- (IBAction)logAction;

@end

