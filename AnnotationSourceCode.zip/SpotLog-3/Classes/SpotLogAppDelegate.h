#import <UIKit/UIKit.h>

@class SpotLogViewController;

@interface SpotLogAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    SpotLogViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet SpotLogViewController *viewController;

@end

