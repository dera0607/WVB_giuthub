#import "SpotLogViewController.h"

@implementation SpotLogAnnotation

@synthesize logDict = _logDict;

- (CLLocationCoordinate2D)coordinate
{
    // 座標を取得する
    CLLocationCoordinate2D  coordinate;
    coordinate.latitude = [[_logDict objectForKey:@"latitude"] doubleValue];
    coordinate.longitude = [[_logDict objectForKey:@"longitude"] doubleValue];
    
    return coordinate;
}

- (NSString*)title
{
    // ログテキストを取得する
    return [_logDict objectForKey:@"log"];
}

@end

#pragma mark -

@implementation SpotLogButton

@synthesize annotation = _annotation;

@end

#pragma mark -

@implementation SpotLogViewController

- (void)showLog:(NSDictionary*)logDict
{
    // アノテーションを作成する
    SpotLogAnnotation*  annotation;
    annotation = [[SpotLogAnnotation alloc] init];
    [annotation autorelease];
    annotation.logDict = logDict;
    
    // アノテーションを追加する
    [_mapView addAnnotation:annotation];
}

- (void)viewDidLoad
{
    // ログを読み込む
    [self loadLogs];
    if (!_logs) {
        _logs = [[NSMutableArray array] retain];
    }
    
    // ログを表示する
    for (NSDictionary* logDict in _logs) {
        [self showLog:logDict];
    }
    
    // ロケーションマネージャを作成する
    _locationManager = [[CLLocationManager alloc] init];
    _locationManager.delegate = self;
    
    // 現在地の更新を開始する
    [_locationManager startUpdatingLocation];
}

- (void)locationManager:(CLLocationManager*)manager 
        didUpdateToLocation:(CLLocation*)newLocation fromLocation:(CLLocation*)oldLocation
{
    // ログボタンを有効化する
    _logButton.enabled = _locationManager.location != nil;
}

- (void)saveLogs
{
    // パスを決定する
    NSArray*    paths;
    NSString*   path;
    paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    path = [[paths objectAtIndex:0] stringByAppendingPathComponent:@"logs"];
    
    // ログを保存する
    NSData* data;
    data = [NSPropertyListSerialization dataFromPropertyList:_logs 
            format:NSPropertyListBinaryFormat_v1_0 
            errorDescription:NULL];
    [data writeToFile:path atomically:YES];
}

- (void)loadLogs
{
    // パスを決定する
    NSArray*    paths;
    NSString*   path;
    paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    path = [[paths objectAtIndex:0] stringByAppendingPathComponent:@"logs"];
    
    // ログを読み込む
    NSData* data;
    data = [NSData dataWithContentsOfFile:path];
    _logs = [NSPropertyListSerialization propertyListFromData:data 
            mutabilityOption:NSPropertyListMutableContainersAndLeaves 
            format:NULL errorDescription:NULL];
    [_logs retain];
}

- (IBAction)logAction
{
    // ログを取得する
    NSString*   log;
    log = _textField.text;
    if ([log length] == 0) {
        return;
    }
    
    // 現在地を取得する
    CLLocation* location;
    location = _locationManager.location;
    
    // ログを追加する
    NSDictionary*   logDict;
    logDict = [NSDictionary dictionaryWithObjectsAndKeys:
            [NSNumber numberWithDouble:location.coordinate.latitude], @"latitude", 
            [NSNumber numberWithDouble:location.coordinate.longitude], @"longitude", 
            [NSDate date], @"date", 
            log, @"log", 
            nil];
    [_logs addObject:logDict];
    
    // ログを表示する
    [self showLog:logDict];
    
    // ログを保存する
    [self saveLogs];
    
    // キーボードを隠す
    [_textField resignFirstResponder];
}

- (void)mapView:(MKMapView*)mapView didAddAnnotationViews:(NSArray*)views
{
    // アノテーションビューを取得する
    for (MKAnnotationView* annotationView in views) {
        // アノテーションがSpotLogAnnotationの場合
        if ([annotationView.annotation isKindOfClass:[SpotLogAnnotation class]]) {
            // ボタンを作成する
            UIButton*   button;
            button = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
            
            // コールアウトのアクセサリビューを設定する
            annotationView.rightCalloutAccessoryView = button;
        }
    }
}

- (void)mapView:(MKMapView*)mapView 
        annotationView:(MKAnnotationView*)view 
        calloutAccessoryControlTapped:(UIControl*)control
{
    // ログを取得する
    NSDictionary*   logDict;
    logDict = ((SpotLogAnnotation*)view.annotation).logDict;
    
    // メッセージを作成する
    NSMutableString*    message;
    message = [NSMutableString string];
    [message appendFormat:@"Date: %@\n", [logDict objectForKey:@"date"]];
    [message appendFormat:@"Lat: %@\n", [logDict objectForKey:@"latitude"]];
    [message appendFormat:@"Lon: %@\n", [logDict objectForKey:@"longitude"]];
    
    // アラートを表示する
    UIAlertView*    alertView;
    alertView = [[UIAlertView alloc] initWithTitle:@"Log Info" message:message 
            delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:NULL];
    [alertView autorelease];
    [alertView show];
}

@end
