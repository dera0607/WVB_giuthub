//
//  SafariActivity.h
//  WVB
//
//  Created by NexSeed on 13/12/13.
//  Copyright (c) 2013年 NexSeed. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SafariActivity : UIActivity

@end
